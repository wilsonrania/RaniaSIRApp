RaniaSIR Android App - Source Project

यह Android प्रोजेक्ट आपकी Blogger वेबसाइट को Android WebView ऐप में खोलता है।
ऐप का नाम: SIR अभिलेख प्रिंट मॉड्यूल
वेबसाइट: https://raniasir.blogspot.com/

मोबाइल से मुफ्त APK बनाने के लिए:
1. GitHub पर नया Public repository बनाएं (उदाहरण: RaniaSIRApp)।
2. इस ZIP को फोन में Extract करें।
3. GitHub repository में Add file > Upload files से प्रोजेक्ट की फाइलें/फ़ोल्डर अपलोड करें।
   ध्यान दें: GitHub मोबाइल साइट पर फ़ोल्डर अपलोड उपलब्ध न हो तो github.com को Chrome में Desktop site करके खोलें।
4. सभी फाइलें अपलोड करके Commit changes करें।
5. Repository में Actions टैब खोलें। Build Android APK workflow चुनें और Run workflow दबाएं।
6. बिल्ड पूरा होने पर workflow run खोलें। नीचे Artifacts में RaniaSIR-debug-apk डाउनलोड करें।
7. ZIP को Extract करके app-debug.apk पर टैप करें। Android अनुमति मांगे तो Chrome/Files के लिए Install unknown apps अनुमति दें।

बिल्ड workflow .github/workflows/android.yml में शामिल है।
GitHub के मुफ्त Actions मिनट्स की सीमा लागू हो सकती है। Public repository के standard GitHub-hosted runners पर सामान्यतः मुफ्त बिल्ड किया जा सकता है।
