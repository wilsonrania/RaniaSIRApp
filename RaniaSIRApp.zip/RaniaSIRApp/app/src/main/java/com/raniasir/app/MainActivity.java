package com.raniasir.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.content.Intent;
import android.content.Context;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.view.MotionEvent;
import android.widget.Magnifier;
import android.os.Build;
import android.content.SharedPreferences;
import android.webkit.WebChromeClient.FileChooserParams;

public class MainActivity extends Activity {
    private WebView webView;
    private ProgressBar progress;
    private FrameLayout splash;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 1001;
    private static final String HOME = "https://raniasir.blogspot.com/";
    private boolean darkMode = false;
    private Magnifier magnifier;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(0);
        SharedPreferences prefs = getSharedPreferences("rania_settings", MODE_PRIVATE);
        darkMode = prefs.getBoolean("dark_mode", false);
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams bar = new FrameLayout.LayoutParams(-1, 6);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(progress, bar);

        // Native theme switch, kept above the website.
        Button themeButton = new Button(this);
        themeButton.setText(darkMode ? "☀ Light" : "☾ Dark");
        themeButton.setTextSize(12);
        themeButton.setAllCaps(false);
        themeButton.setPadding(12, 2, 12, 2);
        FrameLayout.LayoutParams themeLp = new FrameLayout.LayoutParams(-2, 44, Gravity.TOP | Gravity.END);
        themeLp.topMargin = 14;
        themeLp.rightMargin = 10;
        root.addView(themeButton, themeLp);
        themeButton.setOnClickListener(v -> {
            darkMode = !darkMode;
            prefs.edit().putBoolean("dark_mode", darkMode).apply();
            themeButton.setText(darkMode ? "☀ Light" : "☾ Dark");
            applyWebsiteTheme();
        });

        // Show a native magnifier around the point being touched (Android 9+).
        if (Build.VERSION.SDK_INT >= 28) {
            magnifier = new Magnifier(webView);
            webView.setOnTouchListener((v, event) -> {
                if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                    try { magnifier.show(event.getX(), event.getY()); } catch (Exception ignored) {}
                } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    if (magnifier != null) magnifier.dismiss();
                }
                return false;
            });
        }

        // Branded splash shown while the website loads, instead of a blank white screen.
        splash = new FrameLayout(this);
        splash.setBackgroundColor(Color.rgb(16, 42, 67));
        TextView brand = new TextView(this);
        brand.setText("RANIA SIR");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(30);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        TextView loading = new TextView(this);
        loading.setText("Loading...");
        loading.setTextColor(Color.rgb(245, 190, 75));
        loading.setTextSize(15);
        loading.setGravity(Gravity.CENTER);
        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        FrameLayout content = new FrameLayout(this);
        FrameLayout.LayoutParams brandLp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        brandLp.bottomMargin = 78;
        content.addView(brand, brandLp);
        FrameLayout.LayoutParams spinLp = new FrameLayout.LayoutParams(52, 52, Gravity.CENTER);
        spinLp.topMargin = 28;
        content.addView(spinner, spinLp);
        FrameLayout.LayoutParams loadLp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        loadLp.topMargin = 112;
        content.addView(loading, loadLp);
        splash.addView(content, new FrameLayout.LayoutParams(-1, -1));
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // Native Android print bridge for website buttons that call window.print().
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !url.startsWith("https://") && !url.startsWith("http://");
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) { progress.setVisibility(View.VISIBLE); }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                if (splash != null) splash.setVisibility(View.GONE);
                // WebView does not show Android's print dialog for window.print() by default.
                view.evaluateJavascript(
                    "(function(){window.print=function(){if(window.AndroidPrint){AndroidPrint.printPage();}};})();",
                    null
                );
                applyWebsiteTheme();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_PICKER); }
                catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl(HOME);
    }

    private void applyWebsiteTheme() {
        if (webView == null) return;
        String js = "(function(){var id='rania-app-theme';var old=document.getElementById(id);if(old)old.remove();" +
            (darkMode
              ? "var css='html,body{background:#121212!important;color:#eeeeee!important}body,body *{border-color:#444!important}a{color:#8ab4f8!important}input,textarea,select,button{background-color:#242424!important;color:#fff!important}';"
              : "var css='';") +
            "var st=document.createElement('style');st.id=id;st.textContent=css;document.head.appendChild(st);})();";
        webView.evaluateJavascript(js, null);
    }

    private class PrintBridge {
        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> printCurrentPage());
        }
    }

    private void printCurrentPage() {
        if (webView == null) return;
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) return;
        PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("RaniaSIR-Page");
        printManager.print("RaniaSIR-Print", adapter, new PrintAttributes.Builder().build());
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (magnifier != null) { magnifier.dismiss(); magnifier = null; }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
