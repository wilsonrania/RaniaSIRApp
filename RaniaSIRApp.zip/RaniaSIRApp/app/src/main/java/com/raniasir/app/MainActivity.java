package com.raniasir.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.content.Intent;
import android.content.Context;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.os.Build;
import android.content.SharedPreferences;
import android.webkit.WebChromeClient.FileChooserParams;

public class MainActivity extends Activity {
    private WebView webView;
    private ProgressBar progress;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 1001;
    private static final String HOME = "https://raniasir.blogspot.com/";
    private boolean darkMode = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(0);
        SharedPreferences prefs = getSharedPreferences("rania_settings", MODE_PRIVATE);
        darkMode = prefs.getBoolean("dark_mode", false);
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams bar = new FrameLayout.LayoutParams(-1, 6);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(progress, bar);

        // Native theme switch, kept above the website.
        Button themeButton = new Button(this);
        themeButton.setText(darkMode ? "☀ Light" : "☾ Dark");
        themeButton.setTextSize(12);
        themeButton.setAllCaps(false);
        themeButton.setPadding(12, 2, 12, 2);
        FrameLayout.LayoutParams themeLp = new FrameLayout.LayoutParams(-2, 44, Gravity.TOP | Gravity.END);
        themeLp.topMargin = 14;
        themeLp.rightMargin = 10;
        root.addView(themeButton, themeLp);
        themeButton.setOnClickListener(v -> {
            darkMode = !darkMode;
            prefs.edit().putBoolean("dark_mode", darkMode).apply();
            themeButton.setText(darkMode ? "☀ Light" : "☾ Dark");
            applyWebsiteTheme();
        });


        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // Native Android print bridge for website buttons that call window.print().
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !url.startsWith("https://") && !url.startsWith("http://");
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) { progress.setVisibility(View.VISIBLE); }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                // WebView does not show Android's print dialog for window.print() by default.
                view.evaluateJavascript(
                    "(function(){" +
                    "window.print=function(){if(window.AndroidPrint){AndroidPrint.printPage();}};" +
                    "if(!window.__raniaPrintHook){window.__raniaPrintHook=true;document.addEventListener('click',function(e){" +
                    "var el=e.target;while(el&&el!==document){var t=((el.innerText||el.value||el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')).toLowerCase();" +
                    "if(/print|प्रिंट|छापें|मुद्रण/.test(t)){e.preventDefault();e.stopImmediatePropagation();window.print();return;}el=el.parentElement;}},true);}" +
                    "})();",
                    null
                );
                applyWebsiteTheme();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_PICKER); }
                catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl(HOME);
    }

    private void applyWebsiteTheme() {
        if (webView == null) return;
        String css = darkMode
            ? "html,body,#outer-wrapper,#main-wrapper,#content-wrapper,.post,.post-body,.widget,.content-outer{background:#121212!important;color:#f1f1f1!important}" +
              "body,body *{border-color:#444!important}" +
              "p,span,div,td,th,label,h1,h2,h3,h4,h5,h6,li{color:#f1f1f1!important}" +
              "a{color:#8ab4f8!important}" +
              "input,textarea,select,button{background:#242424!important;color:#fff!important;border-color:#666!important}"
            : "html,body,#outer-wrapper,#main-wrapper,#content-wrapper,.post,.post-body,.widget,.content-outer{background:#fff!important;color:#111!important}" +
              "p,span,div,td,th,label,h1,h2,h3,h4,h5,h6,li{color:#111!important}" +
              "a{color:#0645ad!important}" +
              "input,textarea,select,button{background:#fff!important;color:#111!important}";
        String js = "(function(){var id='rania-app-theme';var old=document.getElementById(id);if(old)old.remove();" +
            "var st=document.createElement('style');st.id=id;st.textContent=" + JSONObjectQuote(css) + ";" +
            "(document.head||document.documentElement).appendChild(st);document.documentElement.style.setProperty('background'," + (darkMode ? "'#121212'" : "'#ffffff'") + ",'important');" +
            "})();";
        webView.evaluateJavascript(js, null);
    }

    private String JSONObjectQuote(String value) {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "") + "'";
    }

    private class PrintBridge {
        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> printCurrentPage());
        }
    }

    private void printCurrentPage() {
        if (webView == null) return;
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) return;
        PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("RaniaSIR-Page");
        printManager.print("RaniaSIR-Print", adapter, new PrintAttributes.Builder().build());
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
